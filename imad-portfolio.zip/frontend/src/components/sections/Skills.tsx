// Skills data organized by category
const skillsData = {
    frontend: {
        title: "Frontend",
        icon: "🎨",
        description: "Building beautiful, responsive user interfaces",
        skills: [
            { name: "HTML5", icon: "📄" },
            { name: "CSS3", icon: "🎨" },
            { name: "JavaScript", icon: "⚡" },
            { name: "TypeScript", icon: "📘" },
            { name: "React.js", icon: "⚛️" },
            { name: "Next.js", icon: "▲" },
            { name: "Tailwind CSS", icon: "💨" },
        ],
    },
    backend: {
        title: "Backend & CMS",
        icon: "⚙️",
        description: "Powering applications with robust backends",
        skills: [
            { name: "Node.js", icon: "🟢" },
            { name: "Strapi CMS", icon: "🚀" },
            { name: "REST APIs", icon: "🔗" },
            { name: "PostgreSQL", icon: "🐘" },
            { name: "MongoDB", icon: "🍃" },
        ],
    },
    tools: {
        title: "Tools & Others",
        icon: "🛠️",
        description: "Essential tools for modern development",
        skills: [
            { name: "Git", icon: "📚" },
            { name: "GitHub", icon: "🐙" },
            { name: "VS Code", icon: "💻" },
            { name: "Figma", icon: "🎯" },
            { name: "Vercel", icon: "▲" },
            { name: "npm/pnpm", icon: "📦" },
        ],
    },
};

export default function Skills() {
    return (
        <section id="skills" className="section">
            <div className="container">
                {/* Section Header */}
                <div className="section-heading">
                    <div className="section-tag">Skills & Expertise</div>
                    <h2 className="section-title">
                        Technologies I <span className="gradient-text">Master</span>
                    </h2>
                    <p className="section-description">
                        A comprehensive toolkit for building modern, scalable web applications
                        from frontend to backend.
                    </p>
                </div>

                {/* Skills Grid */}
                <div className="grid-3">
                    {Object.values(skillsData).map((category, categoryIndex) => (
                        <div
                            key={category.title}
                            className="card-glass p-6 hover:border-[var(--accent-primary)] transition-all group"
                            style={{ animationDelay: `${categoryIndex * 0.1}s` }}
                        >
                            {/* Category Header */}
                            <div className="flex items-center gap-3 mb-4">
                                <span className="text-3xl">{category.icon}</span>
                                <div>
                                    <h3 className="text-lg font-bold">{category.title}</h3>
                                    <p className="text-xs text-[var(--text-muted)]">
                                        {category.description}
                                    </p>
                                </div>
                            </div>

                            {/* Skills List */}
                            <div className="space-y-2">
                                {category.skills.map((skill, skillIndex) => (
                                    <div
                                        key={skill.name}
                                        className="flex items-center gap-3 p-2.5 rounded-lg bg-[var(--bg-primary)] border border-transparent hover:border-[var(--border-hover)] transition-all"
                                        style={{ animationDelay: `${(categoryIndex * 0.1) + (skillIndex * 0.05)}s` }}
                                    >
                                        <span className="text-lg">{skill.icon}</span>
                                        <span className="text-sm font-medium text-[var(--text-secondary)] group-hover:text-[var(--text-primary)] transition-colors">
                                            {skill.name}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Additional Skills Banner */}
                <div className="mt-12 p-6 rounded-2xl bg-gradient-to-r from-[var(--accent-glow)] to-transparent border border-[var(--border-default)]">
                    <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                        <div>
                            <h4 className="text-lg font-bold mb-1">Always Learning</h4>
                            <p className="text-sm text-[var(--text-secondary)]">
                                Currently exploring: AI/ML, Cloud Architecture, and Advanced System Design
                            </p>
                        </div>
                        <div className="flex gap-2">
                            {["🤖 AI", "☁️ Cloud", "🏗️ Architecture"].map((item) => (
                                <span key={item} className="badge badge-accent">
                                    {item}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
