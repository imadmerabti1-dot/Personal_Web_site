export default function About() {
    return (
        <section id="about" className="section bg-[var(--bg-secondary)]">
            <div className="container">
                <div className="grid lg:grid-cols-2 gap-12 items-center">
                    {/* Image / Visual Side */}
                    <div className="relative">
                        {/* Profile Image Container */}
                        <div className="relative aspect-square max-w-md mx-auto lg:mx-0">
                            {/* Decorative Elements */}
                            <div className="absolute -inset-4 bg-gradient-to-br from-[var(--accent-primary)] to-purple-600 rounded-2xl opacity-20 blur-xl" />
                            <div className="absolute inset-0 bg-[var(--bg-tertiary)] rounded-2xl border border-[var(--border-default)] overflow-hidden">
                                {/* Placeholder for profile image */}
                                <div className="w-full h-full bg-gradient-to-br from-[var(--bg-tertiary)] to-[var(--bg-primary)] flex items-center justify-center">
                                    <div className="text-center p-8">
                                        <div className="w-32 h-32 mx-auto mb-4 rounded-full bg-gradient-to-br from-[var(--accent-primary)] to-purple-600 flex items-center justify-center text-5xl">
                                            👨‍💻
                                        </div>
                                        <p className="text-[var(--text-muted)] text-sm">
                                            Profile Photo
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Floating Stats Cards */}
                            <div className="absolute -right-4 top-8 card-glass p-4 animate-float">
                                <div className="text-2xl font-bold gradient-text">2+</div>
                                <div className="text-xs text-[var(--text-muted)]">Years Experience</div>
                            </div>

                            <div className="absolute -left-4 bottom-8 card-glass p-4 animate-float" style={{ animationDelay: "0.5s" }}>
                                <div className="text-2xl font-bold gradient-text">15+</div>
                                <div className="text-xs text-[var(--text-muted)]">Projects Delivered</div>
                            </div>
                        </div>
                    </div>

                    {/* Content Side */}
                    <div>
                        <div className="section-tag">About Me</div>
                        <h2 className="section-title">
                            Crafting Digital Excellence with{" "}
                            <span className="gradient-text">Precision & Passion</span>
                        </h2>

                        <div className="space-y-4 text-[var(--text-secondary)]">
                            <p>
                                I&apos;m <strong className="text-[var(--text-primary)]">Imad</strong>,
                                an engineering student from Algeria specializing in Electronics and Artificial Intelligence.
                                Beyond academics, I&apos;ve immersed myself in the world of web development,
                                turning complex problems into elegant, user-centric solutions.
                            </p>

                            <p>
                                My journey in tech is driven by an insatiable curiosity and a commitment to excellence.
                                I believe in writing <strong className="text-[var(--text-primary)]">clean, maintainable code</strong> that
                                not only works today but scales for tomorrow. Every project I undertake is an opportunity
                                to push boundaries and deliver beyond expectations.
                            </p>

                            <p>
                                When I&apos;m not coding, you&apos;ll find me exploring the latest in AI,
                                contributing to open-source projects, or diving deep into system architecture.
                                I&apos;m not just building websites—I&apos;m building a career marked by
                                <strong className="text-[var(--text-primary)]"> discipline, innovation, and impact</strong>.
                            </p>
                        </div>

                        {/* Key Traits */}
                        <div className="mt-8 grid grid-cols-2 gap-4">
                            {[
                                { icon: "🎯", label: "Detail-Oriented" },
                                { icon: "⚡", label: "Fast Learner" },
                                { icon: "🤝", label: "Client-Focused" },
                                { icon: "🚀", label: "Results-Driven" },
                            ].map((trait) => (
                                <div
                                    key={trait.label}
                                    className="flex items-center gap-3 p-3 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-default)]"
                                >
                                    <span className="text-xl">{trait.icon}</span>
                                    <span className="text-sm font-medium">{trait.label}</span>
                                </div>
                            ))}
                        </div>

                        {/* CTA */}
                        <div className="mt-8 flex flex-wrap gap-4">
                            <a href="#contact" className="btn btn-primary">
                                Let&apos;s Work Together
                            </a>
                            <a
                                href="/resume.pdf"
                                target="_blank"
                                className="btn btn-secondary"
                            >
                                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                                </svg>
                                Download CV
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}
