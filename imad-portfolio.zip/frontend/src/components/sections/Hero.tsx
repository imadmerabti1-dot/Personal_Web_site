"use client";

import { useEffect, useRef } from "react";

export default function Hero() {
    const heroRef = useRef<HTMLElement>(null);

    // Parallax effect for background
    useEffect(() => {
        const handleMouseMove = (e: MouseEvent) => {
            if (!heroRef.current) return;
            const x = (e.clientX / window.innerWidth - 0.5) * 20;
            const y = (e.clientY / window.innerHeight - 0.5) * 20;
            heroRef.current.style.setProperty("--mouse-x", `${x}px`);
            heroRef.current.style.setProperty("--mouse-y", `${y}px`);
        };

        window.addEventListener("mousemove", handleMouseMove);
        return () => window.removeEventListener("mousemove", handleMouseMove);
    }, []);

    return (
        <section
            ref={heroRef}
            id="hero"
            className="relative min-h-screen flex items-center justify-center overflow-hidden"
        >
            {/* Animated Background */}
            <div className="absolute inset-0 bg-grid opacity-60" />
            <div
                className="absolute inset-0 bg-gradient-radial"
                style={{
                    transform: "translate(var(--mouse-x, 0), var(--mouse-y, 0))",
                    transition: "transform 0.3s ease-out",
                }}
            />

            {/* Floating Orbs - Decorative */}
            <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-[var(--accent-primary)] rounded-full opacity-10 blur-3xl animate-float" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500 rounded-full opacity-10 blur-3xl animate-float" style={{ animationDelay: "1s" }} />

            {/* Content */}
            <div className="container relative z-10 text-center">
                {/* Status Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[var(--bg-secondary)] border border-[var(--border-default)] mb-8 animate-fade-in">
                    <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-sm text-[var(--text-secondary)]">
                        Available for freelance projects
                    </span>
                </div>

                {/* Main Headline */}
                <h1 className="mb-6 animate-fade-in-up">
                    <span className="block text-[var(--text-secondary)] text-xl md:text-2xl font-medium mb-3">
                        Hi, I&apos;m Imad 👋
                    </span>
                    <span className="block gradient-text">
                        Freelance Web Developer
                    </span>
                    <span className="block mt-2">
                        & Software Engineer
                    </span>
                </h1>

                {/* Subtitle */}
                <p className="max-w-2xl mx-auto text-lg md:text-xl text-[var(--text-secondary)] mb-10 animate-fade-in-up stagger-2">
                    I craft <span className="text-[var(--text-primary)] font-medium">high-performance</span> web experiences
                    that drive results for ambitious businesses. From concept to deployment,
                    I build solutions that{" "}
                    <span className="text-[var(--text-primary)] font-medium">scale</span>.
                </p>

                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up stagger-3">
                    <a href="#projects" className="btn btn-primary">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                        </svg>
                        View My Projects
                    </a>
                    <a href="#contact" className="btn btn-secondary">
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                        </svg>
                        Get in Touch
                    </a>
                </div>

                {/* Tech Stack Preview */}
                <div className="mt-16 pt-8 border-t border-[var(--border-default)] animate-fade-in-up stagger-4">
                    <p className="text-sm text-[var(--text-muted)] mb-4">Powered by modern technologies</p>
                    <div className="flex flex-wrap justify-center gap-4">
                        {["React", "Next.js", "TypeScript", "Tailwind CSS", "Node.js"].map((tech) => (
                            <span
                                key={tech}
                                className="badge"
                            >
                                {tech}
                            </span>
                        ))}
                    </div>
                </div>

                {/* Scroll Indicator */}
                <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
                    <a
                        href="#about"
                        className="flex flex-col items-center gap-2 text-[var(--text-muted)] hover:text-[var(--accent-primary)] transition-colors"
                    >
                        <span className="text-xs uppercase tracking-widest">Scroll</span>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                        </svg>
                    </a>
                </div>
            </div>
        </section>
    );
}
