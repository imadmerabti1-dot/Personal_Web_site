import { FaGithub, FaExternalLinkAlt } from "react-icons/fa";

// Sample projects data (would be fetched from Strapi in production)
const projectsData = [
    {
        id: 1,
        title: "TechFlow Analytics",
        description:
            "A comprehensive analytics dashboard with real-time data visualization, user management, and advanced reporting capabilities.",
        longDescription:
            "Built for a SaaS startup, this dashboard processes millions of data points and presents them in intuitive visualizations.",
        image: "/projects/techflow.jpg",
        technologies: ["Next.js", "TypeScript", "Tailwind CSS", "PostgreSQL", "Chart.js"],
        category: "Full-Stack",
        liveUrl: "https://techflow-demo.vercel.app",
        githubUrl: "https://github.com/imad/techflow",
        featured: true,
    },
    {
        id: 2,
        title: "EcoShop E-commerce",
        description:
            "A modern e-commerce platform with seamless checkout, inventory management, and a beautiful storefront.",
        image: "/projects/ecoshop.jpg",
        technologies: ["React", "Strapi", "Stripe", "Tailwind CSS"],
        category: "E-commerce",
        liveUrl: "https://ecoshop-demo.vercel.app",
        githubUrl: "https://github.com/imad/ecoshop",
        featured: true,
    },
    {
        id: 3,
        title: "DevConnect Platform",
        description:
            "A social networking platform for developers to share projects, collaborate, and grow their network.",
        image: "/projects/devconnect.jpg",
        technologies: ["Next.js", "MongoDB", "Socket.io", "Node.js"],
        category: "Social Platform",
        liveUrl: "https://devconnect-demo.vercel.app",
        githubUrl: "https://github.com/imad/devconnect",
        featured: false,
    },
    {
        id: 4,
        title: "TaskMaster Pro",
        description:
            "An intelligent task management app with AI-powered prioritization and team collaboration features.",
        image: "/projects/taskmaster.jpg",
        technologies: ["React", "Node.js", "OpenAI API", "PostgreSQL"],
        category: "Productivity",
        liveUrl: "https://taskmaster-demo.vercel.app",
        githubUrl: "https://github.com/imad/taskmaster",
        featured: false,
    },
];

export default function Projects() {
    // Get featured project
    const featuredProject = projectsData.find((p) => p.featured);
    const otherProjects = projectsData.filter((p) => p.id !== featuredProject?.id);

    return (
        <section id="projects" className="section bg-[var(--bg-secondary)]">
            <div className="container">
                {/* Section Header */}
                <div className="section-heading">
                    <div className="section-tag">Portfolio</div>
                    <h2 className="section-title">
                        Featured <span className="gradient-text">Projects</span>
                    </h2>
                    <p className="section-description">
                        A selection of projects that showcase my expertise in building
                        modern, scalable web applications.
                    </p>
                </div>

                {/* Featured Project */}
                {featuredProject && (
                    <div className="mb-12">
                        <div className="card-glass overflow-hidden group">
                            <div className="grid lg:grid-cols-2 gap-0">
                                {/* Image Side */}
                                <div className="relative aspect-video lg:aspect-auto overflow-hidden bg-[var(--bg-tertiary)]">
                                    <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-primary)] to-purple-600 opacity-20" />
                                    <div className="absolute inset-0 flex items-center justify-center">
                                        <div className="text-center p-8">
                                            <div className="w-20 h-20 mx-auto mb-4 rounded-xl bg-[var(--bg-primary)] border border-[var(--border-default)] flex items-center justify-center text-4xl">
                                                📊
                                            </div>
                                            <p className="text-sm text-[var(--text-muted)]">
                                                Project Preview
                                            </p>
                                        </div>
                                    </div>
                                    {/* Hover Overlay */}
                                    <div className="absolute inset-0 bg-[var(--accent-primary)]/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                                        <a
                                            href={featuredProject.liveUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="w-12 h-12 rounded-full bg-white text-[var(--accent-primary)] flex items-center justify-center hover:scale-110 transition-transform"
                                        >
                                            <FaExternalLinkAlt />
                                        </a>
                                        <a
                                            href={featuredProject.githubUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="w-12 h-12 rounded-full bg-white text-[var(--accent-primary)] flex items-center justify-center hover:scale-110 transition-transform"
                                        >
                                            <FaGithub />
                                        </a>
                                    </div>
                                </div>

                                {/* Content Side */}
                                <div className="p-8 flex flex-col justify-center">
                                    <div className="inline-flex items-center gap-2 mb-4">
                                        <span className="badge badge-accent">Featured</span>
                                        <span className="badge">{featuredProject.category}</span>
                                    </div>
                                    <h3 className="text-2xl font-bold mb-3">{featuredProject.title}</h3>
                                    <p className="text-[var(--text-secondary)] mb-6">
                                        {featuredProject.description}
                                        {featuredProject.longDescription && (
                                            <span className="block mt-2 text-sm">
                                                {featuredProject.longDescription}
                                            </span>
                                        )}
                                    </p>
                                    <div className="flex flex-wrap gap-2 mb-6">
                                        {featuredProject.technologies.map((tech) => (
                                            <span key={tech} className="badge">
                                                {tech}
                                            </span>
                                        ))}
                                    </div>
                                    <div className="flex gap-4">
                                        <a
                                            href={featuredProject.liveUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="btn btn-primary"
                                        >
                                            <FaExternalLinkAlt className="w-4 h-4" />
                                            Live Demo
                                        </a>
                                        <a
                                            href={featuredProject.githubUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="btn btn-secondary"
                                        >
                                            <FaGithub className="w-4 h-4" />
                                            Source Code
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Other Projects Grid */}
                <div className="grid-3">
                    {otherProjects.map((project) => (
                        <div
                            key={project.id}
                            className="card-glass overflow-hidden group hover:border-[var(--accent-primary)] transition-all"
                        >
                            {/* Project Image */}
                            <div className="relative aspect-video overflow-hidden bg-[var(--bg-tertiary)]">
                                <div className="absolute inset-0 bg-gradient-to-br from-[var(--accent-primary)] to-purple-600 opacity-10" />
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="w-14 h-14 rounded-lg bg-[var(--bg-primary)] border border-[var(--border-default)] flex items-center justify-center text-2xl">
                                        {project.category === "E-commerce" ? "🛍️" :
                                            project.category === "Social Platform" ? "👥" :
                                                project.category === "Productivity" ? "✅" : "💻"}
                                    </div>
                                </div>
                                {/* Hover Overlay */}
                                <div className="absolute inset-0 bg-[var(--accent-primary)]/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                                    <a
                                        href={project.liveUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="w-10 h-10 rounded-full bg-white text-[var(--accent-primary)] flex items-center justify-center hover:scale-110 transition-transform"
                                    >
                                        <FaExternalLinkAlt size={14} />
                                    </a>
                                    <a
                                        href={project.githubUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="w-10 h-10 rounded-full bg-white text-[var(--accent-primary)] flex items-center justify-center hover:scale-110 transition-transform"
                                    >
                                        <FaGithub size={14} />
                                    </a>
                                </div>
                            </div>

                            {/* Project Info */}
                            <div className="p-5">
                                <div className="flex items-center justify-between mb-2">
                                    <span className="badge text-xs">{project.category}</span>
                                </div>
                                <h3 className="text-lg font-bold mb-2 group-hover:text-[var(--accent-primary)] transition-colors">
                                    {project.title}
                                </h3>
                                <p className="text-sm text-[var(--text-secondary)] mb-4 line-clamp-2">
                                    {project.description}
                                </p>
                                <div className="flex flex-wrap gap-1.5">
                                    {project.technologies.slice(0, 3).map((tech) => (
                                        <span key={tech} className="text-xs text-[var(--text-muted)]">
                                            {tech}
                                            {project.technologies.indexOf(tech) < 2 && " •"}
                                        </span>
                                    ))}
                                    {project.technologies.length > 3 && (
                                        <span className="text-xs text-[var(--accent-primary)]">
                                            +{project.technologies.length - 3} more
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                {/* View All CTA */}
                <div className="text-center mt-12">
                    <a
                        href="https://github.com/imad"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="btn btn-secondary"
                    >
                        <FaGithub className="w-5 h-5" />
                        View All Projects on GitHub
                    </a>
                </div>
            </div>
        </section>
    );
}
