const servicesData = [
    {
        icon: "💻",
        title: "Web Development",
        description: "Custom websites built with modern technologies like React, Next.js, and TypeScript.",
        features: ["Responsive Design", "SEO Optimization", "Fast Performance", "Modern UI/UX"],
    },
    {
        icon: "🚀",
        title: "Web Applications",
        description: "Scalable full-stack applications with robust backend integration and dynamic features.",
        features: ["Database Integration", "User Authentication", "API Development", "Real-time Features"],
    },
    {
        icon: "🛍️",
        title: "E-commerce",
        description: "Opimized online stores that convert visitors into loyal customers.",
        features: ["Shopping Cart", "Payment Gateways", "Inventory Management", "Admin Dashboard"],
    },
    {
        icon: "🔧",
        title: "Maintenance",
        description: "Ongoing support and updates to keep your digital products running smoothly.",
        features: ["Performance Updates", "Security Patches", "Content Updates", "Bug Fixes"],
    },
];

export default function Services() {
    return (
        <section id="services" className="section">
            <div className="container">
                {/* Section Header */}
                <div className="section-heading">
                    <div className="section-tag">Services</div>
                    <h2 className="section-title">
                        Solutions That <span className="gradient-text">Drive Growth</span>
                    </h2>
                    <p className="section-description">
                        I help businesses and individuals bring their ideas to life with
                        professional-grade web development services.
                    </p>
                </div>

                {/* Services Grid */}
                <div className="grid-2 lg:grid-cols-4 gap-6">
                    {servicesData.map((service, index) => (
                        <div
                            key={service.title}
                            className="card-glass p-6 hover:-translate-y-2 transition-transform duration-300 group"
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            <div className="w-12 h-12 rounded-lg bg-[var(--bg-tertiary)] border border-[var(--border-default)] flex items-center justify-center text-2xl mb-4 group-hover:scale-110 group-hover:border-[var(--accent-primary)] transition-all">
                                {service.icon}
                            </div>

                            <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                            <p className="text-sm text-[var(--text-secondary)] mb-6">
                                {service.description}
                            </p>

                            <ul className="space-y-2">
                                {service.features.map((feature) => (
                                    <li key={feature} className="flex items-center gap-2 text-sm text-[var(--text-muted)]">
                                        <span className="text-[var(--accent-primary)]">•</span>
                                        {feature}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
