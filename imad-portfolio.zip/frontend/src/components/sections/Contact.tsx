"use client";

import { useState } from "react";
import { FaPaperPlane, FaSpinner } from "react-icons/fa";

export default function Contact() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        subject: "",
        message: "",
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [status, setStatus] = useState<"idle" | "success" | "error">("idle");

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Simulate API call
        setTimeout(() => {
            setIsSubmitting(false);
            setStatus("success");
            setFormData({ name: "", email: "", subject: "", message: "" });

            // Reset status after 5 seconds
            setTimeout(() => setStatus("idle"), 5000);
        }, 1500);
    };

    return (
        <section id="contact" className="section relative overflow-hidden">
            {/* Background Decor */}
            <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-l from-[var(--accent-glow)] to-transparent opacity-30 pointer-events-none" />

            <div className="container relative z-10 w-full">
                <div className="grid lg:grid-cols-2 gap-12 lg:gap-24">
                    {/* Text Content */}
                    <div className="flex flex-col justify-center">
                        <div className="inline-block section-tag mb-4">Get in Touch</div>
                        <h2 className="section-title text-start mb-6">
                            Let&apos;s Build Something <br />
                            <span className="gradient-text">Amazing Together</span>
                        </h2>
                        <p className="text-lg text-[var(--text-secondary)] mb-8">
                            Whether you have a project idea, need a technical consultation, or just want to say hi,
                            My inbox is always open. I usually respond within 24 hours.
                        </p>

                        <div className="space-y-6">
                            <div className="flex items-start gap-4">
                                <div className="w-12 h-12 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border-default)] flex items-center justify-center text-[var(--accent-primary)] shrink-0">
                                    📍
                                </div>
                                <div>
                                    <h4 className="font-bold text-[var(--text-primary)]">Location</h4>
                                    <p className="text-[var(--text-secondary)]">Algiers, Algeria (Available Remote)</p>
                                </div>
                            </div>

                            <div className="flex items-start gap-4">
                                <div className="w-12 h-12 rounded-full bg-[var(--bg-tertiary)] border border-[var(--border-default)] flex items-center justify-center text-[var(--accent-primary)] shrink-0">
                                    ✉️
                                </div>
                                <div>
                                    <h4 className="font-bold text-[var(--text-primary)]">Email</h4>
                                    <a href="mailto:contact@imad.dev" className="text-[var(--text-secondary)] hover:text-[var(--accent-primary)] transition-colors">
                                        contact@imad.dev
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Contact Form */}
                    <div className="card-glass p-8">
                        <h3 className="text-xl font-bold mb-6">Send Me a Message</h3>

                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div className="grid md:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="name" className="form-label">Name</label>
                                    <input
                                        type="text"
                                        id="name"
                                        name="name"
                                        value={formData.name}
                                        onChange={handleChange}
                                        required
                                        className="form-input"
                                        placeholder="John Doe"
                                    />
                                </div>
                                <div>
                                    <label htmlFor="email" className="form-label">Email</label>
                                    <input
                                        type="email"
                                        id="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        required
                                        className="form-input"
                                        placeholder="john@example.com"
                                    />
                                </div>
                            </div>

                            <div>
                                <label htmlFor="subject" className="form-label">Subject</label>
                                <input
                                    type="text"
                                    id="subject"
                                    name="subject"
                                    value={formData.subject}
                                    onChange={handleChange}
                                    required
                                    className="form-input"
                                    placeholder="Project Inquiry"
                                />
                            </div>

                            <div>
                                <label htmlFor="message" className="form-label">Message</label>
                                <textarea
                                    id="message"
                                    name="message"
                                    value={formData.message}
                                    onChange={handleChange}
                                    required
                                    className="form-textarea"
                                    placeholder="Tell me about your project..."
                                />
                            </div>

                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="btn btn-primary w-full"
                            >
                                {isSubmitting ? (
                                    <>
                                        <FaSpinner className="animate-spin" /> Sending...
                                    </>
                                ) : (
                                    <>
                                        <FaPaperPlane /> Send Message
                                    </>
                                )}
                            </button>

                            {status === "success" && (
                                <div className="p-3 bg-green-500/10 border border-green-500/20 text-green-400 rounded-lg text-sm text-center animate-fade-in">
                                    Message sent successfully! I&apos;ll get back to you soon.
                                </div>
                            )}
                        </form>
                    </div>
                </div>
            </div>
        </section>
    );
}
