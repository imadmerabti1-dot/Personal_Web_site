import { FaGithub, FaLinkedin, FaTwitter, FaEnvelope } from "react-icons/fa";

// Social links configuration
const socialLinks = [
    { href: "https://github.com/imad", icon: FaGithub, label: "GitHub" },
    { href: "https://linkedin.com/in/imad", icon: FaLinkedin, label: "LinkedIn" },
    { href: "https://twitter.com/imad", icon: FaTwitter, label: "Twitter" },
    { href: "mailto:contact@imad.dev", icon: FaEnvelope, label: "Email" },
];

// Footer navigation links
const footerLinks = [
    { href: "#about", label: "About" },
    { href: "#projects", label: "Projects" },
    { href: "#services", label: "Services" },
    { href: "#contact", label: "Contact" },
];

export default function Footer() {
    const currentYear = new Date().getFullYear();

    return (
        <footer className="border-t border-[var(--border-default)] bg-[var(--bg-secondary)]">
            <div className="container py-12">
                <div className="grid md:grid-cols-3 gap-8 items-center">
                    {/* Brand */}
                    <div className="text-center md:text-left">
                        <a href="#" className="text-xl font-bold inline-block mb-2">
                            <span className="gradient-text">Imad</span>
                            <span className="text-[var(--text-muted)]">.dev</span>
                        </a>
                        <p className="text-sm text-[var(--text-muted)]">
                            Crafting digital experiences with precision and passion.
                        </p>
                    </div>

                    {/* Quick Links */}
                    <nav className="flex justify-center gap-6">
                        {footerLinks.map((link) => (
                            <a
                                key={link.href}
                                href={link.href}
                                className="text-sm text-[var(--text-secondary)] hover:text-[var(--accent-primary)] transition-colors"
                            >
                                {link.label}
                            </a>
                        ))}
                    </nav>

                    {/* Social Links */}
                    <div className="flex justify-center md:justify-end gap-4">
                        {socialLinks.map((social) => (
                            <a
                                key={social.label}
                                href={social.href}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-10 h-10 rounded-full flex items-center justify-center bg-[var(--bg-tertiary)] text-[var(--text-secondary)] hover:bg-[var(--accent-primary)] hover:text-white transition-all"
                                aria-label={social.label}
                            >
                                <social.icon size={18} />
                            </a>
                        ))}
                    </div>
                </div>

                {/* Bottom Bar */}
                <div className="mt-8 pt-8 border-t border-[var(--border-default)] flex flex-col md:flex-row justify-between items-center gap-4">
                    <p className="text-sm text-[var(--text-muted)]">
                        © {currentYear} Imad. All rights reserved.
                    </p>
                    <p className="text-sm text-[var(--text-muted)]">
                        Built with{" "}
                        <span className="text-[var(--accent-primary)]">Next.js</span> &{" "}
                        <span className="text-[var(--accent-primary)]">Tailwind CSS</span>
                    </p>
                </div>
            </div>

            {/* Back to Top Button */}
            <a
                href="#"
                className="fixed bottom-6 right-6 w-12 h-12 bg-[var(--accent-primary)] text-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-40"
                aria-label="Back to top"
            >
                <svg
                    className="w-5 h-5"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                >
                    <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M5 10l7-7m0 0l7 7m-7-7v18"
                    />
                </svg>
            </a>
        </footer>
    );
}
