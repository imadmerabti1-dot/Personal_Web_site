import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

// Load Inter font with Latin subset for performance
const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

// SEO Metadata Configuration
export const metadata: Metadata = {
  title: "Imad | Freelance Web Developer & Software Engineer",
  metadataBase: new URL("https://imad.dev"),
  description:
    "I'm Imad, a passionate freelance web developer and software engineering student from Algeria. I craft high-performance, modern web experiences using React, Next.js, and cutting-edge technologies.",
  keywords: [
    "Imad",
    "Web Developer",
    "Freelance Developer",
    "React Developer",
    "Next.js Developer",
    "Software Engineer",
    "Algeria",
    "Frontend Developer",
    "Full Stack Developer",
  ],
  authors: [{ name: "Imad" }],
  creator: "Imad",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://imad.dev",
    siteName: "Imad - Web Developer",
    title: "Imad | Freelance Web Developer & Software Engineer",
    description:
      "Crafting high-performance web experiences with modern technologies. Available for freelance projects.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Imad - Freelance Web Developer",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Imad | Freelance Web Developer",
    description: "Crafting high-performance web experiences with modern technologies.",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={inter.variable}>
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
