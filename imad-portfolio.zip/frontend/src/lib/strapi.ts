const STRAPI_URL = process.env.NEXT_PUBLIC_STRAPI_URL || "http://localhost:1337";
const STRAPI_TOKEN = process.env.NEXT_PUBLIC_STRAPI_TOKEN;

/**
 * Helper to fetch data from Strapi API
 * @param endpoint API endpoint (e.g. '/projects')
 * @param params Query parameters object
 * @returns Parsed JSON response
 */
export async function fetchAPI(endpoint: string, params: Record<string, any> = {}) {
    // Construct URL with query parameters
    const url = new URL(`${STRAPI_URL}/api${endpoint}`);

    // Add query parameters
    Object.keys(params).forEach(key => {
        url.searchParams.append(key, params[key]);
    });

    // Fetch options
    const options: RequestInit = {
        headers: {
            "Content-Type": "application/json",
            ...(STRAPI_TOKEN && { Authorization: `Bearer ${STRAPI_TOKEN}` }),
        },
        cache: "no-store", // For dynamic data
    };

    try {
        const res = await fetch(url.toString(), options);

        if (!res.ok) {
            throw new Error(`Failed to fetch from Strapi: ${res.statusText}`);
        }

        const data = await res.json();
        return data;
    } catch (error) {
        console.error(`Strapi Fetch Error (${endpoint}):`, error);
        // Return empty structure to prevent crashes
        return { data: [], meta: {} };
    }
}

/**
 * Get image URL from Strapi media object
 */
export function getStrapiMedia(url: string | null) {
    if (url == null) {
        return null;
    }

    // Return full URL if it's already absolute
    if (url.startsWith("http") || url.startsWith("//")) {
        return url;
    }

    // Otherwise prepend Strapi URL
    return `${STRAPI_URL}${url}`;
}
